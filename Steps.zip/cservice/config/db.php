<?php
// config/db.php
$dsn = 'mysql:host=localhost;dbname=cser'; // Adjust as needed
$username = 'root';
$password = ''; // Enter your DB password
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try {
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
