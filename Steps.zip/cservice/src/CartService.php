<?php
// src/CartService.php
require_once '../config/db.php';

class CartService
{
    // Add a product to the cart
    public static function addItem($user_id, $product_id, $quantity)
    {
        global $pdo;
        $query = "INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$user_id, $product_id, $quantity]);
        return ['status' => 'success', 'message' => 'Item added to cart'];
    }

    // Get all items in the cart
    public static function getItems($user_id)
    {
        global $pdo;
        $query = "SELECT * FROM cart_items WHERE user_id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Remove an item from the cart
    public static function removeItem($user_id, $product_id)
    {
        global $pdo;
        $query = "DELETE FROM cart_items WHERE user_id = ? AND product_id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$user_id, $product_id]);
        return ['status' => 'success', 'message' => 'Item removed from cart'];
    }

    public static function updateItemQuantity($user_id, $product_id, $quantity)
    {
        global $pdo;

        // Ensure quantity is a positive integer
        if ($quantity <= 0) {
            return ['status' => 'error', 'message' => 'Quantity must be greater than zero'];
        }

        // Update the cart item
        $query = "UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$quantity, $user_id, $product_id]);

        // Check if any rows were updated
        if ($stmt->rowCount() > 0) {
            return ['status' => 'success', 'message' => 'Item quantity updated'];
        } else {
            return ['status' => 'error', 'message' => 'Item not found or no change in quantity'];
        }
    }    
}
