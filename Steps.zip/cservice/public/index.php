<?php
require_once '../src/CartService.php';

// Handle preflight requests (OPTIONS method)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    // Return an empty response with the CORS headers for the preflight check
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
    header("Access-Control-Allow-Headers: Content-Type");
    header('HTTP/1.1 200 OK');
    exit;
}
// Allow access from any origin (you can restrict this to specific origins if needed)
header("Access-Control-Allow-Origin: *"); // Use specific domain instead of * for better security
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type");

header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode('/', $uri);
//print_r($uri);
//exit;
if (count($uri) < 3) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid URL']);
    exit;
}

$user_id = $_GET['user_id'];  // You should authenticate users in a real-world app

switch ($method) {
    case 'POST':
        if ($method == 'POST' && isset($uri[2]) && $uri[2] == 'cart' && isset($uri[3]) && $uri[3] == 'add') {
            // Retrieve POST data from form
            $product_id = $_POST['product_id'] ?? null;
            $quantity = $_POST['quantity'] ?? null;
        
            if ($product_id && $quantity) {
                $response = CartService::addItem($user_id, $product_id, $quantity);
                echo json_encode($response);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
            }
        }        
        break;

    case 'GET':
        if ($method == 'GET' && isset($uri[2]) && $uri[2] == 'cart' && isset($uri[3]) && $uri[3] == 'items') {
            // Get items in cart
            $items = CartService::getItems($user_id);
            echo json_encode($items);
        }
        break;

    case 'DELETE':
        if ($method == 'DELETE' && isset($uri[2]) && $uri[2] == 'cart' && isset($uri[3]) && $uri[3] == 'remove') {
            // Retrieve the product_id from query string
            $product_id = $_GET['product_id'] ?? null;
        
            if ($product_id) {
                $response = CartService::removeItem($user_id, $product_id);
                echo json_encode($response);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Missing product_id']);
            }
        }
        break;
        
    case 'PUT':
            if (isset($uri[2]) && $uri[2] == 'cart' && isset($uri[3]) && $uri[3] == 'update') {
                // Update item quantity in cart
                $data = json_decode(file_get_contents("php://input"), true);  // Get JSON input data
                $product_id = $data['product_id'] ?? null;
                $quantity = $data['quantity'] ?? null;
    
                if ($product_id && $quantity) {
                    $response = CartService::updateItemQuantity($user_id, $product_id, $quantity);
                    echo json_encode($response);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Missing product_id or quantity']);
                }
            }
            break;        

    default:
        echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
        break;
}
